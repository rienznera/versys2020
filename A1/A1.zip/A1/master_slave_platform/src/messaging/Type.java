package messaging;

public enum Type {
    INIT, EXE, RES, ERR
}
